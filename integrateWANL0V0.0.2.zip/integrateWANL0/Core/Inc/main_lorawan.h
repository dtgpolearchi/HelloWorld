/*
 * main_lorawan.h
 *
 *  Created on: Mar 30, 2020
 *      Author: apidev
 */

#ifndef INC_MAIN_LORAWAN_H_
#define INC_MAIN_LORAWAN_H_

#include "hw.h"
#include "low_power_manager.h"
#include "lora.h"
#include "bsp.h"
#include "timeServer.h"
#include "vcom.h"
#include "version.h"


typedef struct RxMsg{
	uint8_t header;
	uint16_t config1;
	uint32_t config2;
}RxMsg_t;

void LORA_RxData(lora_AppData_t *AppData);
void LoraStartTx(TxEventType_t EventType);
int main_lora(void);


#endif /* INC_MAIN_LORAWAN_H_ */
